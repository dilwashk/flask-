# Todo

A simple todo-list web application which provides the following functionality:  
• A list of todos  
• Create a new todo item  
• Mark a todo item as done or undone  
• Edit a todo item  
• Delete a todo item  
• Mark everything as completed  

The project makes use of Python3, Flask, SQLite, Bootstrap and JQuery.

