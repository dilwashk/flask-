"""
Settings file for the application.
"""

APP_ID = '841a28ce9a464522bae12e9001d22ec8'
